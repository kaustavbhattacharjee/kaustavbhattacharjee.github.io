/* Google MAP Settings*/
var lat= 22.4873001;  //Change the value with your address Latitude
var lng= 88.3344841;  //Change the value with your address Longitude
  
//Skill Chart Data
var skillData = {
	skill1: [
		{
			title: "Hadoop ",
            color: "#00C5CD",
			border: "4px solid #f4709f",
			value: '90%'
		},
		{
			title: "Map Reduce ",
            color: "#00C5CD",
			border: "4px solid #f4709f",
			value: '100%'
		},
		{
			title: "Pig ",
            color: "#00C5CD",
			border: "4px solid #f4709f",
			value: '80%'
		},
        {
            title: "Hive ",
            color: "#00C5CD",
            border: "4px solid #f4709f",
            value: '95%'
        }
    
	],
	skill2: [
		{
			title: "HTML ",
			color: "#1b7ee4",
			border: "4px solid #8cc2f9",
			value: '90%'
		},
		{
			title: "CSS ",
			color: "#1b7ee4",
			border: "4px solid #8cc2f9",
			value: '75%'
		},
		{
			title: "JavaScript ",
			color: "#1b7ee4",
			border: "4px solid #8cc2f9",
			value: '90%'
		},
        {
            title: "PHP ",
            color: "#1b7ee4",
            border: "4px solid #8cc2f9",
            value: '95%'
        },
    {
        title: "JQuery ",
        color: "#1b7ee4",
        border: "4px solid #8cc2f9",
        value: '85%'
		}
	],
  skill3: [
		{
			title: "Java ",
            color: "#00CC66",
			border: "4px solid #e4f9b1",
			value: '85%'
		},
      {
          title: "DataBase Management Systems ",
          color: "#00CC66",
          border: "4px solid #e4f9b1",
          value: '95%'
      },
		{
			title: "Linux ",
            color: "#00CC66",
			border: "4px solid #e4f9b1",
			value: '70%'
		},
    {
			title: "Data Structure",
            color: "#00CC66",
			border: "4px solid #e4f9b1",
			value: '85%'
		},
		{
			title: "Operating Systems ",
            color: "#00CC66",
			border: "4px solid #e4f9b1",
			value: '90%'
		}
	]
}
